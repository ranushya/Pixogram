import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { FooterComponent } from './com/footer/footer.component';
import { SignCardComponent } from './com/sign-card/sign-card.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { RegisterComponent } from './register/register.component';
import { MyMediaPageComponent } from './my-media-page/my-media-page.component';
import { UploadMediaSingleComponent } from './upload-media/upload-media-single/upload-media-single.component';
import { UploadMediaMultipleComponent } from './upload-media/upload-media-multiple/upload-media-multiple.component';
import { UserCardComponent } from './com/user-card/user-card.component';
import { MediaCardComponent } from './com/media-card/media-card.component';
import { MediaHolderCardComponent } from './com/media-holder-card/media-holder-card.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { AccountUpdateComponent } from './account-update/account-update.component';
import { BlockedAccountsComponent } from './blocked-accounts/blocked-accounts.component';
import { NewsFeedComponent } from './news-feed/news-feed.component';
import { SearchComponent } from './search/search.component';
import { UploadMediaComponent } from './upload-media/upload-media.component';
import { FollowComponent } from './follow/follow.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { UsersComponent } from './users/users.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HeaderComponent } from './com/header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SignCardComponent,
    SignInComponent,
    RegisterComponent,
    MyMediaPageComponent,
    UploadMediaSingleComponent,
    UploadMediaMultipleComponent,
    UserCardComponent,
    MediaCardComponent,
    MediaHolderCardComponent,
   
    AccountDetailsComponent,
    AccountUpdateComponent,
    BlockedAccountsComponent,
    NewsFeedComponent,
    SearchComponent,
    UploadMediaComponent,
    FollowComponent,
    UsersComponent,
  
    PageNotFoundComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
  
    HttpClientModule
  ],
  
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
