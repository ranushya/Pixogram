import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/model/user';
import { UserAuthService } from 'src/services/user-auth.service';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {

  username: String;
  email: String;
  password: String;
  rPassword: String;
  userId: number;

  constructor(private router: Router, private loginService: UserAuthService) { }


  ngOnInit() {
    let userId=localStorage.getItem("userId");
    this.userId = parseInt(userId);
    console.log(userId);

  }
  update(){
    console.log(this.email);
    let user = new User(this.username, this.email, this.password);
    console.log(this.email);
    this.loginService.updateUser(this.userId,user).subscribe(response => console.log(response));

  }
  onSubmit() {
  console.log("asd");
  
    this.update();
    
  }

}
