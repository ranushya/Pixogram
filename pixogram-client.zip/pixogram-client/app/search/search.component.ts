import { Component, OnInit } from '@angular/core';
import { User } from 'src/model/user';
import { UserAuthService } from 'src/services/user-auth.service';
import { Router } from '@angular/router';
import { FollowService } from 'src/services/follow.service';
import { Follow } from 'src/model/follow';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  userName: String;
  followers: any;
  followings: any;
  userId: number;
  options;
  followersUserDetails;
  followingsUserDetails;
  toggle: Map<number, boolean>;
  search:User[];

  constructor(private router: Router, private follow: FollowService,private userService: UserAuthService) { }

  ngOnInit() {
    this.userName=null;
    let userId = localStorage.getItem("userId");
    this.userId = parseInt(userId);
    if (!userId) {
      alert("Logged out of your account, Please Login again")
      this.router.navigate(['sign-in']);
      return;
    }
  }
  private searchUser() {
    this.userService.getUserByName(this.userName)
    .subscribe(search => this.search= search);
   
  }

  fetchFollowers() {
    this.follow.getFollowers(this.userId).subscribe(response => {
      console.log(response);
      this.followers = response;
      let length = this.followers.length;
      this.followersUserDetails = [];
      for (let i = 0; i < length; i++) {
        this.userService.getUserById(this.followers[i].userId).subscribe(response => {
          this.followersUserDetails.push(response);
        });
      }
      console.log(this.followersUserDetails);
    });
  }

  fetchFollowings() {
    this.follow.getFollowings(this.userId).subscribe(response => {
      console.log(response);
      this.followings = response;
      let length = this.followings.length;
      this.followingsUserDetails = [];
      this.toggle = new Map<number, boolean>();
      for (let i = 0; i < length; i++) {
        this.userService.getUserById(this.followings[i].followId).subscribe(response => {
          this.followingsUserDetails.push(response);
          this.toggle.set(response.id, true);
        });
      }
      console.log(this.followingsUserDetails);
    });
  }

  followUser(followId) {
    let followObj = new Follow(this.userId, followId);
    this.follow.follow(followObj).subscribe(res => {
      console.log(res);
      this.fetchFollowers();
      this.fetchFollowings();
    });
    this.toggle.set(followId, true);
  }

  onSubmit()
  {
    this.searchUser();
  }
  
}
